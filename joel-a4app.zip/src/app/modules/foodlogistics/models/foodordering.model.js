"use strict";
var FoodOrder = (function () {
    function FoodOrder(restaurantguid, orderid, restaurantlocation, destination, timezone, startime, endtime, date, receiptid, receiptamount, driverid, drivercarregno, drivername, driverphoneno) {
        this.restaurantguid = restaurantguid;
        this.orderid = orderid;
        this.restaurantlocation = restaurantlocation;
        this.destination = destination;
        this.timezone = timezone;
        this.startime = startime;
        this.endtime = endtime;
        this.date = date;
        this.receiptid = receiptid;
        this.receiptamount = receiptamount;
        this.driverid = driverid;
        this.drivercarregno = drivercarregno;
        this.drivername = drivername;
        this.driverphoneno = driverphoneno;
    }
    return FoodOrder;
}());
exports.FoodOrder = FoodOrder;
//# sourceMappingURL=foodordering.model.js.map