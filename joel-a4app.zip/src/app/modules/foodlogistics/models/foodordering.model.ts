export class FoodOrder{
    constructor(public restaurantguid:string, public orderid:string,public restaurantlocation:string, public destination:string, public timezone:string, public startime:string, public endtime:string, public date:string, public receiptid:string, public receiptamount:number, public driverid:string, public drivercarregno:string,public drivername:string, public driverphoneno:string){

    }
}
