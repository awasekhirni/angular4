import { Component, OnInit } from '@angular/core';
import {Http,HttpModule,RequestOptions,Response,Request} from '@angular/http';
import {Observable} from 'rxjs/Rx'; 
import 'rxjs/add/operator/map';
import { FoodOrderingService } from '../services/foodorderingservice';

@Component({
    selector: 'food-ordering-list',
    templateUrl: './htmlviews/foodordering.html'
})

export class FoodOrderingListComponent implements OnInit {
    foodorderList:any=[];
    constructor(private _fos:FoodOrderingService) { }

    ngOnInit() { 

        this._fos.fetchFoodOrder().subscribe(results=>{
            this.foodorderList=results;
            console.log(this.foodorderList);
        })
    }
}