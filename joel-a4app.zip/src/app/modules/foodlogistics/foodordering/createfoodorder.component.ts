import { Component } from '@angular/core';
import { FoodOrder } from '../models/foodordering.model';
import {FormsModule} from '@angular/forms';

@Component({
    selector: 'create-food-order',
    templateUrl: './htmlviews/createfoodorder.html'
})

export class CreateFoodOrderComponent  {
    
    
    constructor() { }

    uberorder=new FoodOrder("05ea23fb-b0d4-44bd-a4df-ddbf2ca100a2",    "ad6887fd-42e0-4007-bfb0-9b670709759c",
     "9296 8th Parkway",
     "0 Elka Road",
     "Europe/Moscow",
     "6:12 PM",
     "5:57 PM",
    "2018/06/29",
     "7163955b-cc3c-41c8-aece-8e2c9107ff96",
    50,
    "8dc6af81-1f99-480b-8353-cab1f4dab664",
     "4405531197566794",
     "Alane Ilott",
     "548-763-2464");

    
}