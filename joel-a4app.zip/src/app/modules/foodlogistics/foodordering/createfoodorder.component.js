"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var foodordering_model_1 = require("../models/foodordering.model");
var CreateFoodOrderComponent = (function () {
    function CreateFoodOrderComponent() {
        this.uberorder = new foodordering_model_1.FoodOrder("05ea23fb-b0d4-44bd-a4df-ddbf2ca100a2", "ad6887fd-42e0-4007-bfb0-9b670709759c", "9296 8th Parkway", "0 Elka Road", "Europe/Moscow", "6:12 PM", "5:57 PM", "2018/06/29", "7163955b-cc3c-41c8-aece-8e2c9107ff96", 50, "8dc6af81-1f99-480b-8353-cab1f4dab664", "4405531197566794", "Alane Ilott", "548-763-2464");
    }
    return CreateFoodOrderComponent;
}());
CreateFoodOrderComponent = __decorate([
    core_1.Component({
        selector: 'create-food-order',
        templateUrl: './htmlviews/createfoodorder.html'
    }),
    __metadata("design:paramtypes", [])
], CreateFoodOrderComponent);
exports.CreateFoodOrderComponent = CreateFoodOrderComponent;
//# sourceMappingURL=createfoodorder.component.js.map