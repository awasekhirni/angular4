import { Component } from '@angular/core';

@Component({
    selector: 'configuration-component',
    templateUrl: './htmlviews/configuration.html'
})

export class ConfigurationComponent  {
    constructor() { }

    
}