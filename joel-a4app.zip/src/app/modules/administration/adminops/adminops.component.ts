import { Component } from '@angular/core';

@Component({
    selector: 'admin-operations',
    templateUrl: './htmlviews/adminops.html'
})

export class AdminOpsComponent  {
    constructor() { }

    
}