import { Component } from '@angular/core';

@Component({
    selector: 'user-management',
    templateUrl: './htmlviews/usermgmt.html'
})

export class UserManagementComponent  {
    constructor() { }

    
}