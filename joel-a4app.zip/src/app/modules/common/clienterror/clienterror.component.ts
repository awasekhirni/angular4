import { Component } from '@angular/core';

@Component({
    selector: 'client-error',
    templateUrl: './htmlviews/404.html'
})

export class ClientErrorComponent  {
    constructor() { }

    
}