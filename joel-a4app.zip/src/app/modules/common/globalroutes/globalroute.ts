import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SigninComponent } from '../../authentication/signin/signin.component';
import { SignoutComponent } from '../../authentication/signout/signout.component';
import { SignupComponent } from '../../authentication/signup/signup.component';
import { AuthErrorComponent } from '../../authentication/autherror/autherror.component';
import { UserManagementComponent } from '../../administration/usermgmt/usermgmt.component';
import { ConfigurationComponent } from '../../administration/configurations/configuration.component';
import { AdminOpsComponent } from '../../administration/adminops/adminops.component';
import { SignsuccessComponent } from '../../authentication/signsuccess/signsuccess.component';
import { FoodOrderingListComponent } from '../../foodlogistics/foodordering/foodorderinglist.component';
import { TravelBookingListComponent } from '../../travellogistics/travelbooking/travelbookinglist.component';
import { CreateFoodOrderComponent } from '../../foodlogistics/foodordering/createfoodorder.component';

const glblroutes: Routes = [
    { path:'*',pathMatch:'full',redirectTo:'auth/login'},
    { component:SigninComponent,path:'auth/login',pathMatch:'full'},
    { component:SignoutComponent,path:'auth/logout',pathMatch:'full'},
    { component:SignupComponent,path:'auth/register',pathMatch:'full'},
    { component:AuthErrorComponent,path:'auth/autherror',pathMatch:'full'},
    { component:UserManagementComponent,path:'admin/usrmgmt',pathMatch:'full'},
    { component:ConfigurationComponent,path:'admin/configurator',pathMatch:'full'},
    { component:AdminOpsComponent,path:'admin/ops',pathMatch:'full'},
    { component:SignsuccessComponent,path:'auth/home',pathMatch:'full'},
    { component:FoodOrderingListComponent,path:'foodlogistics/foodorder',pathMatch:'full'},
    { component:TravelBookingListComponent,path:'travellogistics/travelbooking',pathMatch:'full'},
    { component:CreateFoodOrderComponent,path:'foodlogistics/createfoodorder',pathMatch:'full'}
]

@NgModule({
    imports: [RouterModule.forRoot(glblroutes)],
    exports: [RouterModule],
    declarations: [],
})
export class AppRoutingModule { }