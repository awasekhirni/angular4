"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var signin_component_1 = require("../../authentication/signin/signin.component");
var signout_component_1 = require("../../authentication/signout/signout.component");
var signup_component_1 = require("../../authentication/signup/signup.component");
var autherror_component_1 = require("../../authentication/autherror/autherror.component");
var usermgmt_component_1 = require("../../administration/usermgmt/usermgmt.component");
var configuration_component_1 = require("../../administration/configurations/configuration.component");
var adminops_component_1 = require("../../administration/adminops/adminops.component");
var signsuccess_component_1 = require("../../authentication/signsuccess/signsuccess.component");
var foodorderinglist_component_1 = require("../../foodlogistics/foodordering/foodorderinglist.component");
var travelbookinglist_component_1 = require("../../travellogistics/travelbooking/travelbookinglist.component");
var createfoodorder_component_1 = require("../../foodlogistics/foodordering/createfoodorder.component");
var glblroutes = [
    { path: '*', pathMatch: 'full', redirectTo: 'auth/login' },
    { component: signin_component_1.SigninComponent, path: 'auth/login', pathMatch: 'full' },
    { component: signout_component_1.SignoutComponent, path: 'auth/logout', pathMatch: 'full' },
    { component: signup_component_1.SignupComponent, path: 'auth/register', pathMatch: 'full' },
    { component: autherror_component_1.AuthErrorComponent, path: 'auth/autherror', pathMatch: 'full' },
    { component: usermgmt_component_1.UserManagementComponent, path: 'admin/usrmgmt', pathMatch: 'full' },
    { component: configuration_component_1.ConfigurationComponent, path: 'admin/configurator', pathMatch: 'full' },
    { component: adminops_component_1.AdminOpsComponent, path: 'admin/ops', pathMatch: 'full' },
    { component: signsuccess_component_1.SignsuccessComponent, path: 'auth/home', pathMatch: 'full' },
    { component: foodorderinglist_component_1.FoodOrderingListComponent, path: 'foodlogistics/foodorder', pathMatch: 'full' },
    { component: travelbookinglist_component_1.TravelBookingListComponent, path: 'travellogistics/travelbooking', pathMatch: 'full' },
    { component: createfoodorder_component_1.CreateFoodOrderComponent, path: 'foodlogistics/createfoodorder', pathMatch: 'full' }
];
var AppRoutingModule = (function () {
    function AppRoutingModule() {
    }
    return AppRoutingModule;
}());
AppRoutingModule = __decorate([
    core_1.NgModule({
        imports: [router_1.RouterModule.forRoot(glblroutes)],
        exports: [router_1.RouterModule],
        declarations: [],
    })
], AppRoutingModule);
exports.AppRoutingModule = AppRoutingModule;
//# sourceMappingURL=globalroute.js.map