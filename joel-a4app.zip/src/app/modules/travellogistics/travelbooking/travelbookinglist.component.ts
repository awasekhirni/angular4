import { Component, OnInit } from '@angular/core';
import {Http,HttpModule,RequestOptions,Response,Request} from '@angular/http';
import {Observable} from 'rxjs/Rx'; 
import 'rxjs/add/operator/map';
import { TravelBookingService } from '../services/travelbookingservice';


@Component({
    selector: 'travel-booking-list',
    templateUrl: './htmlviews/travelbookinglist.html'
})

export class TravelBookingListComponent implements OnInit {
    travelbookingList:any=[];
    constructor(private _tbs:TravelBookingService) { }

    
    ngOnInit() { 

        this._tbs.fetchBooking().subscribe(results=>{
            this.travelbookingList=results;
            console.log(this.travelbookingList);
        });
    }
}