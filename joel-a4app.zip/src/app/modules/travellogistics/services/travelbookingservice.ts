import { Injectable } from '@angular/core';
import {Http,HttpModule, JsonpModule,Request,RequestOptions,Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';


@Injectable()
export class TravelBookingService {

    travelRESTAPI='https://raw.githubusercontent.com/awasekhirni/jsondata/master/carbooking-mock.json';
    errorLog: any=[];

    
  
  

    constructor(private _http:Http) { }

    //createbooking 
    createBooking(){

    }

    //updatebooking
    updateBooking(){

    }

    //deletebooking 
    deleteBooking(){

    }

    //getbooking 
    fetchBooking(){
       return this._http.get(this.travelRESTAPI).map((response:Response)=>response.json()).catch(this.handleError)
    }
    handleError(error:any) {
        // In a real world app, we might use a remote logging infrastructure
        // We'd also dig deeper into the error to get a better message
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
        this.errorLog = errMsg;
        return Observable.throw(errMsg);
    }


}