import { Component } from '@angular/core';

@Component({
    selector: 'sign-out',
    templateUrl: './htmlviews/signout.html'
})

export class SignoutComponent  {
    constructor() { }

    
}