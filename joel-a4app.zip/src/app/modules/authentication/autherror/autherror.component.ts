import { Component } from '@angular/core';

@Component({
    selector: 'authentication-error',
    templateUrl: './htmlviews/autherror.html'
})

export class AuthErrorComponent  {
    constructor() { }

    
}