import { Component } from '@angular/core';

@Component({
    selector: 'sign-in',
    templateUrl: './htmlviews/signin.html'
})

export class SigninComponent  {
    constructor() { }

    
}