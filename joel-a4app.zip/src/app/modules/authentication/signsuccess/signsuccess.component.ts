import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sign-success',
    templateUrl: './htmlviews/home.html'
})

export class SignsuccessComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}