import { Component } from '@angular/core';

@Component({
    selector: 'sign-up',
    templateUrl: './htmlviews/signup.html'
})

export class SignupComponent  {
    constructor() { }

    
}