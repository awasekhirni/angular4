import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './htmlviews/masterroot.html',
})
export class AppComponent  { }
