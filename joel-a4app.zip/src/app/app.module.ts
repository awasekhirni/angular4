import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './modules/common/globalroutes/globalroute';
import { SigninComponent } from './modules/authentication/signin/signin.component';
import { SignoutComponent } from './modules/authentication/signout/signout.component';
import { SignupComponent } from './modules/authentication/signup/signup.component';
import { AuthErrorComponent } from './modules/authentication/autherror/autherror.component';
import { AdminOpsComponent } from './modules/administration/adminops/adminops.component';
import { UserManagementComponent } from './modules/administration/usermgmt/usermgmt.component';
import { ConfigurationComponent } from './modules/administration/configurations/configuration.component';
import { SignsuccessComponent } from './modules/authentication/signsuccess/signsuccess.component';
import { TravelBookingService } from './modules/travellogistics/services/travelbookingservice';
import { FoodOrderingService } from './modules/foodlogistics/services/foodorderingservice';
import { HttpModule, JsonpModule } from '@angular/http';
import { FoodOrderingListComponent } from './modules/foodlogistics/foodordering/foodorderinglist.component';
import { TravelBookingListComponent } from './modules/travellogistics/travelbooking/travelbookinglist.component';
import { CreateFoodOrderComponent } from './modules/foodlogistics/foodordering/createfoodorder.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports:      [ BrowserModule,RouterModule,AppRoutingModule,HttpModule,JsonpModule,FormsModule ],
  declarations: [ AppComponent,SigninComponent,SignoutComponent,SignupComponent,AuthErrorComponent,AdminOpsComponent,UserManagementComponent,ConfigurationComponent,SignsuccessComponent,FoodOrderingListComponent,TravelBookingListComponent,CreateFoodOrderComponent],
  bootstrap:    [ AppComponent ],
  providers:[TravelBookingService,FoodOrderingService]
})
export class AppModule { }
