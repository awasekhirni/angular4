"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var app_component_1 = require("./app.component");
var router_1 = require("@angular/router");
var globalroute_1 = require("./modules/common/globalroutes/globalroute");
var signin_component_1 = require("./modules/authentication/signin/signin.component");
var signout_component_1 = require("./modules/authentication/signout/signout.component");
var signup_component_1 = require("./modules/authentication/signup/signup.component");
var autherror_component_1 = require("./modules/authentication/autherror/autherror.component");
var adminops_component_1 = require("./modules/administration/adminops/adminops.component");
var usermgmt_component_1 = require("./modules/administration/usermgmt/usermgmt.component");
var configuration_component_1 = require("./modules/administration/configurations/configuration.component");
var signsuccess_component_1 = require("./modules/authentication/signsuccess/signsuccess.component");
var travelbookingservice_1 = require("./modules/travellogistics/services/travelbookingservice");
var foodorderingservice_1 = require("./modules/foodlogistics/services/foodorderingservice");
var http_1 = require("@angular/http");
var foodorderinglist_component_1 = require("./modules/foodlogistics/foodordering/foodorderinglist.component");
var travelbookinglist_component_1 = require("./modules/travellogistics/travelbooking/travelbookinglist.component");
var createfoodorder_component_1 = require("./modules/foodlogistics/foodordering/createfoodorder.component");
var forms_1 = require("@angular/forms");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, router_1.RouterModule, globalroute_1.AppRoutingModule, http_1.HttpModule, http_1.JsonpModule, forms_1.FormsModule],
        declarations: [app_component_1.AppComponent, signin_component_1.SigninComponent, signout_component_1.SignoutComponent, signup_component_1.SignupComponent, autherror_component_1.AuthErrorComponent, adminops_component_1.AdminOpsComponent, usermgmt_component_1.UserManagementComponent, configuration_component_1.ConfigurationComponent, signsuccess_component_1.SignsuccessComponent, foodorderinglist_component_1.FoodOrderingListComponent, travelbookinglist_component_1.TravelBookingListComponent, createfoodorder_component_1.CreateFoodOrderComponent],
        bootstrap: [app_component_1.AppComponent],
        providers: [travelbookingservice_1.TravelBookingService, foodorderingservice_1.FoodOrderingService]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map